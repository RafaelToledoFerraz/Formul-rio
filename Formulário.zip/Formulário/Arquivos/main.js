const btnEnviar = document.getElementById('btnEnviar');

const nameInput = document.getElementById('nome');
const mailInput = document.getElementById('mail');
const msgInput = document.getElementById('msg');

const nameError = document.getElementById('nomeError');
const mailError = document.getElementById('mailError');
const msgError = document.getElementById('msgError');

const msgSend = document.getElementById('msgSend')

btnEnviar.addEventListener('click',()=>{
    if (nameInput.value.length <4){
        nameError.style.display='block'
        nameInput.style.borderColor = 'red' 
    } 
    else{
        nameError.style.display='none'
        nameInput.style.borderColor = 'green'
    }
    if (mailInput.value.length == 0){
        mailError.style.display='block'
        mailInput.style.borderColor = 'red'
    } else{
        mailError.style.display='none'
        mailInput.style.borderColor = 'green'
    }
    if (msgInput.value.length == 0){
        msgError.style.display='block'
        msgInput.style.borderColor = 'red'
    } else{
        msgError.style.display='none'
        msgInput.style.borderColor = 'green'
    }

    if (nameInput.value.length >= 4 && mailInput.value.length >0 &&
        msgInput.value.length >0) {
        msgSend.style.display = 'block'
        } else {
            msgSend.style.display = 'none'
        }

})